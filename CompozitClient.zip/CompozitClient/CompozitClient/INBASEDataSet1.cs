﻿namespace CompozitClient
{
}

namespace CompozitClient
{


    public partial class INBASEDataSet1
    {
    }
}
namespace CompozitClient {
    
    
    public partial class INBASEDataSet1 {
    }
}

namespace CompozitClient.INBASEDataSet1TableAdapters {
    
    
    public partial class DEVICETableAdapter {
    }
}
